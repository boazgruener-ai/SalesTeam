import {
  getTopics,
  saveTopics,
  getJobTopics,
  saveJobTopics,
  getResults,
  getTimeframe,
  saveTimeframe,
  getAuthorTitles,
  saveAuthorTitles,
  getAuthorTitleEnabled,
  saveAuthorTitleEnabled,
  getIncludeJobAds,
  saveIncludeJobAds,
  getJobSearchEnabled,
  saveJobSearchEnabled,
  getJobSearchUsePostTopics,
  saveJobSearchUsePostTopics,
  getJobSearchLocation,
  saveJobSearchLocation,
  getJobSearchLocationPresets,
  saveJobSearchLocationPresets,
  getJobSearchTimeframe,
  saveJobSearchTimeframe,
  getAnthropicApiKey,
  saveAnthropicApiKey,
  getMessageTemplates,
  saveMessageTemplates,
  getValueAddOffers,
  saveValueAddOffers,
  getCompanyContext,
  saveCompanyContext,
  getMentorPersona,
  saveMentorPersona,
  getCustomerPersona,
  saveCustomerPersona,
  getOutputLanguage,
  saveOutputLanguage,
  updateResultDraft,
  getAdvisorHistory,
  saveAdvisorHistory,
  clearAdvisorHistory,
  getCustomerVoiceHistory,
  saveCustomerVoiceHistory,
  clearCustomerVoiceHistory,
  clearResults,
  exportSettings,
  importSettings,
} from "./storage.js";
import { sortResultsByRelevance } from "./ranking.js";

const topicsListEl = document.getElementById("topics-list");
const addTopicBtn = document.getElementById("add-topic-btn");
const jobTopicsListEl = document.getElementById("job-topics-list");
const addJobTopicBtn = document.getElementById("add-job-topic-btn");
const scanBtn = document.getElementById("scan-btn");
const progressTextEl = document.getElementById("progress-text");
const resultsListEl = document.getElementById("results-list");
const clearResultsBtn = document.getElementById("clear-results-btn");
const timeframeSelect = document.getElementById("timeframe-select");
const authorTitleInput = document.getElementById("author-title-input");
const authorTitleEnabledCheckbox = document.getElementById("author-title-enabled-checkbox");
const includeJobAdsCheckbox = document.getElementById("include-job-ads-checkbox");
const jobSearchEnabledCheckbox = document.getElementById("job-search-enabled-checkbox");
const jobSearchUsePostTopicsCheckbox = document.getElementById("job-search-use-post-topics-checkbox");
const jobSearchLocationSelect = document.getElementById("job-search-location-select");
const newJobLocationNameInput = document.getElementById("new-job-location-name");
const newJobLocationGeoIdInput = document.getElementById("new-job-location-geoid");
const addJobLocationBtn = document.getElementById("add-job-location-btn");
const jobSearchTimeframeSelect = document.getElementById("job-search-timeframe-select");
const exportBtn = document.getElementById("export-btn");
const exportIncludeApiKeyCheckbox = document.getElementById("export-include-api-key-checkbox");
const importBtn = document.getElementById("import-btn");
const importFileInput = document.getElementById("import-file-input");
const exportCsvBtn = document.getElementById("export-csv-btn");
const anthropicApiKeyInput = document.getElementById("anthropic-api-key-input");
const messageTemplatesListEl = document.getElementById("message-templates-list");
const valueAddOffersInput = document.getElementById("value-add-offers-input");
const companyContextInput = document.getElementById("company-context-input");
const outputLanguageSelect = document.getElementById("output-language-select");
const advisorHistoryEl = document.getElementById("advisor-history");
const advisorStatusEl = document.getElementById("advisor-status");
const advisorInput = document.getElementById("advisor-input");
const advisorSendBtn = document.getElementById("advisor-send-btn");
const advisorClearBtn = document.getElementById("advisor-clear-btn");
const mentorPersonaInput = document.getElementById("mentor-persona-input");
const customerPersonaInput = document.getElementById("customer-persona-input");
const customerHistoryEl = document.getElementById("customer-history");
const customerStatusEl = document.getElementById("customer-status");
const customerInput = document.getElementById("customer-input");
const customerSendBtn = document.getElementById("customer-send-btn");
const customerClearBtn = document.getElementById("customer-clear-btn");

let topics = [];
let jobTopics = [];
let jobLocationPresets = [];
let messageTemplates = [];
let valueAddOffers = [];
let companyContext = "";
let mentorPersona = "";
let customerPersona = "";
let outputLanguage = "english";

function languageInstruction() {
  return outputLanguage === "german"
    ? "Write your entire response in German (Hochdeutsch/standard business German), not English."
    : "Write your entire response in English.";
}

// Cheap/fast model, well-suited to drafting a short message - see the
// environment's model list for current Claude model IDs.
const DRAFT_MODEL = "claude-haiku-4-5-20251001";

// A stronger model for the Sales Advisor - giving real prioritization/
// approach advice is a genuine reasoning task, unlike a short templated
// draft, so it's worth the extra cost/latency over Haiku.
const ADVISOR_MODEL = "claude-sonnet-5";

// Mirrors the limits in background.js - a single OR-group tops out at 6
// terms, and when a topic's optional second "AND with" group is used, the
// combined total across both groups tops out at 9. Lists longer than this
// get auto-split into multiple sub-searches at scan time.
const MAX_OR_TERMS = 6;
const TOTAL_TERM_BUDGET = 9;

// Mirrors background.js's splitBudget() exactly - when both a topic's
// keyword group and its "AND with" group are large, LinkedIn's 9-term
// combined ceiling forces both chunk sizes to shrink below 6, which is what
// makes concept-chunks × AND-chunks multiply up fast. This lets the topic
// editor show the real number of searches a topic will run, instead of the
// user finding out only after asking for a manual audit.
function splitBudget(countA, countB) {
  let sizeA = Math.min(MAX_OR_TERMS, countA);
  let sizeB = Math.min(MAX_OR_TERMS, countB);
  while (sizeA + sizeB > TOTAL_TERM_BUDGET && (sizeA > 1 || sizeB > 1)) {
    if (sizeA >= sizeB && sizeA > 1) sizeA--;
    else if (sizeB > 1) sizeB--;
    else break;
  }
  return { sizeA, sizeB };
}

// Post topics: concept-chunks × AND-chunks (multiplicative) once an AND
// group is present - matches background.js's planTopicChunks.
function countPostSubQueries(keywordCount, andKeywordCount) {
  if (keywordCount === 0) return 0;
  if (andKeywordCount === 0) return Math.ceil(keywordCount / MAX_OR_TERMS);
  const { sizeA, sizeB } = splitBudget(keywordCount, andKeywordCount);
  return Math.ceil(keywordCount / sizeA) * Math.ceil(andKeywordCount / sizeB);
}

// Job topics: one flat combined OR-list (both groups merged), chunked
// straight by MAX_OR_TERMS - matches background.js's jobKeywordChunks.
function countJobSubQueries(keywordCount, andKeywordCount) {
  const total = keywordCount + andKeywordCount;
  return total === 0 ? 0 : Math.ceil(total / MAX_OR_TERMS);
}

function topicChunkHint(keywordCount, andKeywordCount, mode) {
  const n = mode === "jobs"
    ? countJobSubQueries(keywordCount, andKeywordCount)
    : countPostSubQueries(keywordCount, andKeywordCount);
  if (n <= 1) return { text: n === 1 ? "1 search for this topic." : "", warn: false };
  return {
    text: `${n} searches for this topic — LinkedIn splits large keyword lists into multiple searches ` +
      `automatically, so this one topic takes ${n}× as long as a single search.`,
    warn: n >= 6,
  };
}

function newTopic() {
  return { id: crypto.randomUUID(), name: "", keywords: [], andKeywords: [], enabled: true };
}

function applyChunkHint(hintEl, keywordCount, andKeywordCount, mode) {
  const { text, warn } = topicChunkHint(keywordCount, andKeywordCount, mode);
  hintEl.textContent = text;
  hintEl.classList.toggle("keyword-limit-hint-warn", warn);
}

// Shared renderer for both the Post topics list and the Job-specific topics
// list - they're the exact same data shape and editing UI, just persisted
// and stored separately. mode ("posts" or "jobs") picks which chunking math
// the live search-count hint uses, since the two verticals chunk differently.
function renderTopicCards(topicsArray, listEl, { onUpdate, onRemove, mode }) {
  listEl.innerHTML = "";

  if (topicsArray.length === 0) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "No topics yet. Add one below.";
    listEl.appendChild(empty);
    return;
  }

  for (const topic of topicsArray) {
    if (topic.enabled === undefined) topic.enabled = true;
    if (!topic.andKeywords) topic.andKeywords = [];

    const card = document.createElement("div");
    card.className = "topic-card";
    if (!topic.enabled) card.classList.add("topic-disabled");

    const headerRow = document.createElement("div");
    headerRow.className = "topic-header-row";

    const enabledCheckbox = document.createElement("input");
    enabledCheckbox.type = "checkbox";
    enabledCheckbox.checked = topic.enabled;
    enabledCheckbox.title = "Include this topic in the next scan";
    enabledCheckbox.addEventListener("change", () => {
      topic.enabled = enabledCheckbox.checked;
      card.classList.toggle("topic-disabled", !topic.enabled);
      onUpdate();
    });

    const nameInput = document.createElement("input");
    nameInput.type = "text";
    nameInput.placeholder = "Topic name (e.g. AI Transformation)";
    nameInput.value = topic.name;
    // "input" (not "change") so this is persisted immediately on every
    // keystroke - otherwise a scan started before blurring the field would
    // read a stale (possibly still-empty) name/keyword list from storage.
    nameInput.addEventListener("input", () => {
      topic.name = nameInput.value;
      onUpdate();
    });

    headerRow.append(enabledCheckbox, nameInput);

    const keywordsTextarea = document.createElement("textarea");
    keywordsTextarea.placeholder = "One keyword or phrase per line";
    keywordsTextarea.value = topic.keywords.join("\n");

    const andLabel = document.createElement("label");
    andLabel.className = "and-keywords-label";
    andLabel.textContent = "AND with (optional) — post must ALSO mention one of these";

    const andKeywordsTextarea = document.createElement("textarea");
    andKeywordsTextarea.placeholder = "e.g. project, development, transformation";
    andKeywordsTextarea.value = topic.andKeywords.join("\n");

    const keywordsHint = document.createElement("p");
    keywordsHint.className = "keyword-limit-hint";
    applyChunkHint(keywordsHint, topic.keywords.length, topic.andKeywords.length, mode);

    keywordsTextarea.addEventListener("input", () => {
      topic.keywords = keywordsTextarea.value
        .split("\n")
        .map((line) => line.trim())
        .filter((line) => line.length > 0);
      applyChunkHint(keywordsHint, topic.keywords.length, topic.andKeywords.length, mode);
      onUpdate();
    });

    andKeywordsTextarea.addEventListener("input", () => {
      topic.andKeywords = andKeywordsTextarea.value
        .split("\n")
        .map((line) => line.trim())
        .filter((line) => line.length > 0);
      applyChunkHint(keywordsHint, topic.keywords.length, topic.andKeywords.length, mode);
      onUpdate();
    });

    const removeBtn = document.createElement("button");
    removeBtn.type = "button";
    removeBtn.className = "remove-topic-btn";
    removeBtn.textContent = "Remove topic";
    removeBtn.addEventListener("click", () => onRemove(topic));

    card.append(headerRow, keywordsTextarea, andLabel, andKeywordsTextarea, keywordsHint, removeBtn);
    listEl.appendChild(card);
  }
}

async function persistTopics() {
  await saveTopics(topics);
}

function renderTopics() {
  renderTopicCards(topics, topicsListEl, {
    onUpdate: persistTopics,
    onRemove: (topic) => {
      topics = topics.filter((t) => t.id !== topic.id);
      persistTopics();
      renderTopics();
    },
    mode: "posts",
  });
}

async function persistJobTopics() {
  await saveJobTopics(jobTopics);
}

function renderJobTopics() {
  renderTopicCards(jobTopics, jobTopicsListEl, {
    onUpdate: persistJobTopics,
    onRemove: (topic) => {
      jobTopics = jobTopics.filter((t) => t.id !== topic.id);
      persistJobTopics();
      renderJobTopics();
    },
    mode: "jobs",
  });
}

addTopicBtn.addEventListener("click", () => {
  topics.push(newTopic());
  persistTopics();
  renderTopics();
});

addJobTopicBtn.addEventListener("click", () => {
  jobTopics.push(newTopic());
  persistJobTopics();
  renderJobTopics();
});

function renderJobLocationOptions(selectedValue) {
  jobSearchLocationSelect.innerHTML = "";

  const anyOption = document.createElement("option");
  anyOption.value = "";
  anyOption.textContent = "Any location";
  jobSearchLocationSelect.appendChild(anyOption);

  for (const preset of jobLocationPresets) {
    const option = document.createElement("option");
    option.value = preset.geoId;
    option.textContent = preset.name;
    jobSearchLocationSelect.appendChild(option);
  }

  jobSearchLocationSelect.value = selectedValue || "";
}

addJobLocationBtn.addEventListener("click", async () => {
  const name = newJobLocationNameInput.value.trim();
  const geoId = newJobLocationGeoIdInput.value.trim();
  if (!name || !geoId) {
    alert("Enter both a location name and its geoId (found via the live-page URL inspection trick).");
    return;
  }

  jobLocationPresets.push({ name, geoId });
  await saveJobSearchLocationPresets(jobLocationPresets);
  renderJobLocationOptions(geoId);
  await saveJobSearchLocation(geoId);

  newJobLocationNameInput.value = "";
  newJobLocationGeoIdInput.value = "";
});

function renderMessageTemplates() {
  messageTemplatesListEl.innerHTML = "";
  for (const template of messageTemplates) {
    const wrap = document.createElement("div");
    wrap.className = "template-card";

    const label = document.createElement("div");
    label.className = "template-name";
    label.textContent = template.name;

    const textarea = document.createElement("textarea");
    textarea.value = template.instructions;
    textarea.addEventListener("input", () => {
      template.instructions = textarea.value;
      saveMessageTemplates(messageTemplates);
    });

    wrap.append(label, textarea);
    messageTemplatesListEl.appendChild(wrap);
  }
}

function findTemplateId(id) {
  return messageTemplates.find((t) => t.id === id)?.id || messageTemplates[0]?.id;
}

// Picks the template that best fits a lead's situation - a 1st-degree
// connection gets a warmer tone, a hiring/job-ad post gets acknowledgment of
// what they're building out, and everything else gets the soft cold-contact
// template. Always overridable per-lead via the template dropdown.
//
// Deliberately checks isJobAd only, not isHiringPost - isJobAd means LinkedIn's
// own embedded job-listing widget was present (a reliable structural signal),
// while isHiringPost is a looser phrase-match ("we're looking for...") that
// also fires on unrelated posts like "looking for feedback/beta users" and
// would pick the wrong tone for an actual outreach message.
function pickDefaultTemplateId(result) {
  if (result.isJobAd) return findTemplateId("hiring-lead");
  if (result.connectionDegree === "1st") return findTemplateId("first-degree");
  return findTemplateId("warm-content");
}

function buildDraftPrompt(result, template) {
  const context = `Name: ${result.author}\nHeadline: ${result.headline || "n/a"}\nTheir post: "${result.snippet || ""}"`;
  const topicNames = result.matchedTopics.map((t) => t.topicName).join(", ");
  const connectionLine = `Connection status: ${
    result.connectionDegree ? result.connectionDegree + "-degree connection" : "not yet connected"
  }`;
  const offersLine =
    valueAddOffers.length > 0 ? valueAddOffers.join("; ") : "none available - do not offer anything specific";
  const companyLine = companyContext.trim()
    ? `What the salesperson's own company actually sells: ${companyContext.trim()}`
    : "";

  return `You are helping a B2B software & AI-services salesperson write a short, polite, non-pushy opening LinkedIn message to a potential lead.
${companyLine ? "\n" + companyLine + "\n" : ""}
${context}
Matched on: ${topicNames}
${connectionLine}

Style instructions for this situation:
${template.instructions}

Optional resource you may mention, ONLY if it genuinely fits the message naturally (do not force it in, and never invent any other resource, link, offer, or fact beyond what's listed here):
${offersLine}

Write ONLY the message text itself - no subject line, no greeting like "Dear", no explanation, no quotation marks around it. Keep it under 80 words. Do not sound like a template. Never invent facts about the person or company beyond what's given above.

${languageInstruction()}`;
}

// Shared by the per-lead "Draft Message" button and the Sales Advisor
// agent's draft_message tool, so both go through the exact same prompt and
// persistence logic. Throws on failure; callers decide how to surface that.
async function generateDraft(result, templateId) {
  const apiKey = sanitizeApiKey((await getAnthropicApiKey()) || "");
  if (!apiKey) throw new Error("No Anthropic API key configured - add one in the AI Message Drafting settings.");

  const template = messageTemplates.find((t) => t.id === templateId) || messageTemplates[0];
  if (!template) throw new Error("No message templates configured.");

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: DRAFT_MODEL,
      max_tokens: 300,
      messages: [{ role: "user", content: buildDraftPrompt(result, template) }],
    }),
  });

  if (!response.ok) {
    const errBody = await response.text();
    throw new Error(`API error ${response.status}: ${errBody.slice(0, 200)}`);
  }

  const data = await response.json();
  const draft = (data.content || []).map((block) => block.text || "").join("").trim();
  if (!draft) throw new Error("Empty response from API.");

  await updateResultDraft(result.key, { draftMessage: draft, draftTemplateId: template.id });
  return draft;
}

async function draftMessageForLead(result, templateId, { draftTextarea, statusEl, draftBtn }) {
  draftBtn.disabled = true;
  statusEl.textContent = "Drafting…";
  try {
    draftTextarea.value = await generateDraft(result, templateId);
    statusEl.textContent = "";
  } catch (err) {
    statusEl.textContent = `Couldn't draft a message: ${err.message}`;
  } finally {
    draftBtn.disabled = false;
  }
}

// Draft-then-copy only, by design: the salesperson always pastes into
// LinkedIn's own message box and hits send themselves. Nothing here ever
// auto-sends or auto-fills LinkedIn's compose UI - see the pitch deck's
// "safe by design" slide for why.
function buildDraftSection(card, result) {
  const section = document.createElement("div");
  section.className = "draft-section";

  const controls = document.createElement("div");
  controls.className = "draft-controls";

  const select = document.createElement("select");
  select.className = "draft-template-select";
  for (const template of messageTemplates) {
    const option = document.createElement("option");
    option.value = template.id;
    option.textContent = template.name;
    select.appendChild(option);
  }
  select.value = result.draftTemplateId || pickDefaultTemplateId(result);

  const draftBtn = document.createElement("button");
  draftBtn.type = "button";
  draftBtn.className = "draft-btn";
  draftBtn.textContent = "Draft Message";

  controls.append(select, draftBtn);

  const textarea = document.createElement("textarea");
  textarea.className = "draft-textarea";
  textarea.placeholder =
    "Click “Draft Message” to generate a suggested opening message, then edit it to sound like you " +
    "before sending it yourself on LinkedIn.";
  textarea.value = result.draftMessage || "";

  const actionsRow = document.createElement("div");
  actionsRow.className = "draft-actions";

  const statusEl = document.createElement("span");
  statusEl.className = "draft-status";

  const copyBtn = document.createElement("button");
  copyBtn.type = "button";
  copyBtn.className = "copy-draft-btn";
  copyBtn.textContent = "Copy";
  copyBtn.addEventListener("click", async () => {
    if (!textarea.value.trim()) return;
    await navigator.clipboard.writeText(textarea.value);
    statusEl.textContent = "Copied — paste it into LinkedIn's message box and review before sending.";
    setTimeout(() => {
      if (statusEl.textContent.startsWith("Copied")) statusEl.textContent = "";
    }, 4000);
  });

  actionsRow.append(copyBtn, statusEl);

  draftBtn.addEventListener("click", () => {
    draftMessageForLead(result, select.value, { draftTextarea: textarea, statusEl, draftBtn });
  });

  section.append(controls, textarea, actionsRow);
  card.appendChild(section);
}

// ---------------------------------------------------------------------
// The "AI board of advisors": two agents (Sales Mentor, Customer Voice)
// built from the same reusable chat engine below, each with its own
// persona/system prompt and tool access. Unlike the single-shot prompt
// used for message drafting above, both are given "tools" (function
// definitions) and decide for themselves, mid-conversation, whether they
// need to call one before answering - e.g. surveying leads before
// recommending which to prioritize, or looking up a specific lead's real
// post before reacting to it in character. This loop (call the API, run
// whatever tool it asked for, feed the result back, repeat until it
// returns plain text) is the actual mechanism behind "agentic AI". All
// tools only ever read/generate local data already in the Results list -
// none of them touch LinkedIn or send anything, so there's no new risk
// from giving either agent this much autonomy.
// ---------------------------------------------------------------------

const LEAD_LOOKUP_TOOLS = [
  {
    name: "list_leads",
    description:
      "Returns a summary of all currently scanned Post leads (job listings from LinkedIn's Jobs vertical " +
      "have no individual contact and are excluded). Use this to survey what's available before " +
      "recommending which to prioritize.",
    input_schema: {
      type: "object",
      properties: {
        only_not_yet_drafted: {
          type: "boolean",
          description: "If true, only include leads that don't have a drafted message yet.",
        },
      },
    },
  },
  {
    name: "get_lead_details",
    description:
      "Returns full details for one specific lead by its key (from list_leads), including its full post " +
      "text and any existing draft. Use this before reasoning in depth about one particular person.",
    input_schema: {
      type: "object",
      properties: {
        key: { type: "string", description: "The lead's key, as returned by list_leads." },
      },
      required: ["key"],
    },
  },
];

const DRAFT_MESSAGE_TOOL = {
  name: "draft_message",
  description:
    "Generates a suggested opening LinkedIn message for one lead, using the same logic as the 'Draft " +
    "Message' button. Only works for Post-type leads. The draft is shown to the human for review on that " +
    "lead's card - it is never sent automatically.",
  input_schema: {
    type: "object",
    properties: {
      key: { type: "string", description: "The lead's key." },
      template_id: {
        type: "string",
        description:
          "Optional: 'first-degree', 'warm-content', or 'hiring-lead'. If omitted, the best-fitting one " +
          "is picked automatically based on the lead's connection status and content.",
      },
    },
    required: ["key"],
  },
};

async function toolListLeads({ only_not_yet_drafted } = {}) {
  const resultsMap = await getResults();
  const sorted = sortResultsByRelevance(resultsMap);
  return sorted
    .filter((r) => r.type !== "job")
    .filter((r) => !only_not_yet_drafted || !r.draftMessage)
    .map((r) => ({
      key: r.key,
      author: r.author,
      headline: r.headline,
      matchedTopics: r.matchedTopics.map((t) => t.topicName),
      connectionDegree: r.connectionDegree || "unknown",
      isJobAd: r.isJobAd,
      isHiringPost: r.isHiringPost,
      isFreelancePost: r.isFreelancePost,
      hasDraft: Boolean(r.draftMessage),
    }));
}

async function toolGetLeadDetails({ key }) {
  const resultsMap = await getResults();
  const r = resultsMap[key];
  if (!r) return { error: "No lead found with that key." };
  return {
    key: r.key,
    author: r.author,
    headline: r.headline,
    snippet: r.snippet,
    profileUrl: r.profileUrl,
    matchedTopics: r.matchedTopics,
    connectionDegree: r.connectionDegree || "unknown",
    isJobAd: r.isJobAd,
    isHiringPost: r.isHiringPost,
    isFreelancePost: r.isFreelancePost,
    existingDraft: r.draftMessage || null,
  };
}

async function toolDraftMessage({ key, template_id }) {
  const resultsMap = await getResults();
  const r = resultsMap[key];
  if (!r || r.type === "job") return { error: "No contactable Post lead found with that key." };

  const templateId =
    template_id && messageTemplates.some((t) => t.id === template_id) ? template_id : pickDefaultTemplateId(r);

  try {
    const draft = await generateDraft(r, templateId);
    renderResultsFromStorage(); // refresh the lead card so the new draft is visible there too
    return { draft, templateId };
  } catch (err) {
    return { error: err.message };
  }
}

// The Sales Mentor can also draft messages as part of its advice; the
// Customer Voice is read-only - reacting to a message isn't the same as
// being able to write one.
async function executeMentorTool(name, input) {
  if (name === "list_leads") return toolListLeads(input || {});
  if (name === "get_lead_details") return toolGetLeadDetails(input || {});
  if (name === "draft_message") return toolDraftMessage(input || {});
  return { error: `Unknown tool: ${name}` };
}

async function executeReadOnlyLeadTool(name, input) {
  if (name === "list_leads") return toolListLeads(input || {});
  if (name === "get_lead_details") return toolGetLeadDetails(input || {});
  return { error: `Unknown tool: ${name}` };
}

// Both prompts are built fresh per turn (not fixed constants) so they always
// pick up the latest "What We Offer" text from settings - without this,
// neither agent has any idea what the salesperson's company actually sells,
// and can only react to a lead's own post in isolation rather than reason
// about real fit.
function companyContextBlock() {
  return companyContext.trim()
    ? `\nWhat the salesperson's own company actually sells: ${companyContext.trim()}\n`
    : "\n(No company/offering description has been configured yet - reason generically, and note that " +
        "more specific advice would be possible once one is added in settings.)\n";
}

function buildMentorSystemPrompt() {
  return (
    `You are acting as a sales mentor to a salesperson working real leads found by their LinkedIn Lead ` +
    `Scanner extension. Your persona: ${mentorPersona.trim() || "a senior, approachable B2B sales expert"}. ` +
    "There's no such thing as a stupid question." +
    companyContextBlock() +
    "When a question is about specific leads (which to prioritize, how to approach one by name), use the " +
    "list_leads and get_lead_details tools to ground your answer in real, current data - never guess or " +
    "invent leads or their content. Reason about REAL fit against what the salesperson's company actually " +
    "sells (above), not just what the lead's post happens to say - a lead can be a poor fit even if their " +
    "post sounds relevant, or a good fit for a different reason than it first appears. When asked a general " +
    "sales-strategy or process question not tied to a specific lead, answer directly from your own expertise " +
    "instead - you don't need a tool for that. When asked to draft or write a message, use the draft_message " +
    "tool rather than writing one yourself directly, so it goes through the same reviewed process as " +
    "everywhere else in the extension. Be direct, practical, and specific - reference actual leads by name " +
    "when relevant. Keep answers focused; a few short paragraphs or a short list is plenty, no need to pad." +
    "\n" + languageInstruction()
  );
}

function customerPersonaBlock() {
  return customerPersona.trim()
    ? `\nYour default persona, when no specific lead is named: ${customerPersona.trim()}\n`
    : "";
}

function buildCustomerSystemPrompt() {
  return (
    "You are playing the role of a realistic B2B buyer of software & AI-services - the kind of person a " +
    "salesperson using this extension is trying to reach." +
    companyContextBlock() +
    customerPersonaBlock() +
    "The salesperson will ask you to react to a proposed message, approach, or offer that pitches the " +
    "company above, or ask general questions about what buyers like you care about. When the question names " +
    "or clearly points to one specific lead (by name or key), use the list_leads and get_lead_details tools " +
    "to ground yourself in that real person's actual post/headline/situation, and react as they specifically " +
    "would - reference their real content over the default persona above, and never invent facts or traits " +
    "beyond what's given. When asked a general question not tied to one specific lead (e.g. what's your main " +
    "pain point with AI projects today), answer in character as the default persona above if one is given, " +
    "or as a knowledgeable, realistic composite of a typical buyer in this space otherwise - and make clear " +
    "this is a general perspective, not one specific person's view. Be honest and even critical - point out " +
    "specifically what would make you ignore a message, what would make you reply, and why. Keep answers " +
    "concise and concrete.\n" +
    "Language: when grounded in one specific real lead (via get_lead_details or list_leads), respond in " +
    "that lead's own post's language, whatever it is - that's what a real reaction from them would sound " +
    "like, even if it differs from the instruction below. For general questions with no specific lead " +
    "grounding your answer, use this instead: " + languageInstruction()
  );
}

// Reusable engine behind every agent persona in this extension: a small
// wrapper around the tool-use loop (call the API, run any requested tools,
// feed results back, repeat until a plain-text answer comes back), wired to
// one set of DOM elements and one persisted history. Each persona below is
// just a different config of the same engine - same mechanism, different
// system prompt and tool access.
function createAgentChat({ buildSystemPrompt, tools, historyEl, statusEl, inputEl, sendBtn, clearBtn, executeTool, getHistoryFn, saveHistoryFn, clearHistoryFn }) {
  let history = [];

  function appendBubble(kind, text) {
    const bubble = document.createElement("div");
    bubble.className = `agent-bubble agent-bubble-${kind}`;
    bubble.textContent = text;
    historyEl.appendChild(bubble);
    historyEl.scrollTop = historyEl.scrollHeight;
  }

  // Renders from the raw Anthropic API message shape - user turns are plain
  // strings, assistant turns are arrays of content blocks (text and/or
  // tool_use), and tool-result turns (also role "user") are internal
  // plumbing the human doesn't need to see directly, so only the
  // "🔧 Checking..." line for the tool_use that triggered them is shown.
  function render() {
    historyEl.innerHTML = "";
    for (const message of history) {
      if (message.role === "user" && typeof message.content === "string") {
        appendBubble("you", message.content);
      } else if (message.role === "assistant") {
        for (const block of message.content) {
          if (block.type === "text" && block.text.trim()) {
            appendBubble("agent", block.text);
          } else if (block.type === "tool_use") {
            appendBubble("tool", `🔧 Checking: ${block.name}`);
          }
        }
      }
    }
  }

  async function runTurn(userText) {
    history.push({ role: "user", content: userText });
    await saveHistoryFn(history);
    render();

    const apiKey = sanitizeApiKey((await getAnthropicApiKey()) || "");
    if (!apiKey) {
      history.push({
        role: "assistant",
        content: [{ type: "text", text: "Add your Anthropic API key in the AI Message Drafting settings above first." }],
      });
      await saveHistoryFn(history);
      render();
      return;
    }

    sendBtn.disabled = true;

    try {
      // Tool-use loop: keep calling the API and executing whatever tool it
      // asks for until it returns a plain-text answer (stop_reason !==
      // "tool_use"), or we hit a sane round limit as a safety valve.
      for (let round = 0; round < 6; round++) {
        statusEl.textContent = round === 0 ? "Thinking…" : "Thinking some more…";

        const response = await fetch("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: {
            "content-type": "application/json",
            "x-api-key": apiKey,
            "anthropic-version": "2023-06-01",
            "anthropic-dangerous-direct-browser-access": "true",
          },
          body: JSON.stringify({
            model: ADVISOR_MODEL,
            max_tokens: 2048,
            system: buildSystemPrompt(),
            tools,
            messages: history,
          }),
        });

        if (!response.ok) {
          const errBody = await response.text();
          throw new Error(`API error ${response.status}: ${errBody.slice(0, 200)}`);
        }

        const data = await response.json();
        history.push({ role: "assistant", content: data.content });
        render();

        if (data.stop_reason !== "tool_use") {
          await saveHistoryFn(history);
          return;
        }

        const toolUses = data.content.filter((block) => block.type === "tool_use");
        const toolResults = [];
        for (const toolUse of toolUses) {
          statusEl.textContent = `Using tool: ${toolUse.name}…`;
          const result = await executeTool(toolUse.name, toolUse.input);
          toolResults.push({ type: "tool_result", tool_use_id: toolUse.id, content: JSON.stringify(result) });
        }
        history.push({ role: "user", content: toolResults });
      }

      history.push({
        role: "assistant",
        content: [{ type: "text", text: "(Stopped after several tool calls without a final answer - try rephrasing.)" }],
      });
      await saveHistoryFn(history);
      render();
    } catch (err) {
      history.push({ role: "assistant", content: [{ type: "text", text: `Something went wrong: ${err.message}` }] });
      await saveHistoryFn(history);
      render();
    } finally {
      statusEl.textContent = "";
      sendBtn.disabled = false;
    }
  }

  function send() {
    const text = inputEl.value.trim();
    if (!text) return;
    inputEl.value = "";
    runTurn(text);
  }

  sendBtn.addEventListener("click", send);
  inputEl.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      send();
    }
  });
  clearBtn.addEventListener("click", async () => {
    if (!confirm("Clear this conversation? This can't be undone.")) return;
    history = [];
    await clearHistoryFn();
    render();
  });

  return {
    async init() {
      history = await getHistoryFn();
      render();
    },
  };
}

const salesMentor = createAgentChat({
  buildSystemPrompt: buildMentorSystemPrompt,
  tools: [...LEAD_LOOKUP_TOOLS, DRAFT_MESSAGE_TOOL],
  historyEl: advisorHistoryEl,
  statusEl: advisorStatusEl,
  inputEl: advisorInput,
  sendBtn: advisorSendBtn,
  clearBtn: advisorClearBtn,
  executeTool: executeMentorTool,
  getHistoryFn: getAdvisorHistory,
  saveHistoryFn: saveAdvisorHistory,
  clearHistoryFn: clearAdvisorHistory,
});

const customerVoice = createAgentChat({
  buildSystemPrompt: buildCustomerSystemPrompt,
  tools: LEAD_LOOKUP_TOOLS,
  historyEl: customerHistoryEl,
  statusEl: customerStatusEl,
  inputEl: customerInput,
  sendBtn: customerSendBtn,
  clearBtn: customerClearBtn,
  executeTool: executeReadOnlyLeadTool,
  getHistoryFn: getCustomerVoiceHistory,
  saveHistoryFn: saveCustomerVoiceHistory,
  clearHistoryFn: clearCustomerVoiceHistory,
});

function csvEscape(value) {
  const text = String(value ?? "");
  if (/[",\n]/.test(text)) {
    return `"${text.replace(/"/g, '""')}"`;
  }
  return text;
}

function formatDate(epochMs) {
  return epochMs ? new Date(epochMs).toLocaleDateString() : "";
}

function resultsToCsv(sortedResults) {
  const headers = [
    "Type",
    "Author / Job Title",
    "Headline / Company",
    "Location",
    "Topics",
    "Matched Keywords",
    "Snippet",
    "Profile URL",
    "Post/Job URL",
    "Posted",
    "In-Post Job Ad",
    "Hiring Post",
    "Freelance/Contract Post",
    "First Found",
  ];
  const rows = sortedResults.map((r) => {
    const topicNames = r.matchedTopics.map((t) => t.topicName).join("; ");
    const allKeywords = [...new Set(r.matchedTopics.flatMap((t) => t.matchedKeywords || []))].join("; ");
    const isJob = r.type === "job";
    return [
      isJob ? "Job Listing" : "Post",
      isJob ? r.title : r.author,
      isJob ? r.company : r.headline,
      isJob ? r.location : "",
      topicNames,
      allKeywords,
      isJob ? "" : r.snippet,
      isJob ? "" : r.profileUrl,
      isJob ? r.jobUrl : r.postUrl,
      isJob ? r.postedText : r.timestampText,
      !isJob && r.isJobAd ? "Yes" : "No",
      !isJob && r.isHiringPost ? "Yes" : "No",
      !isJob && r.isFreelancePost ? "Yes" : "No",
      formatDate(r.firstSeenAt),
    ];
  });
  return [headers, ...rows].map((row) => row.map(csvEscape).join(",")).join("\r\n");
}

function buildTagsEl(matchedTopics) {
  const tags = document.createElement("div");
  tags.className = "topic-tags";
  for (const match of matchedTopics) {
    const tag = document.createElement("span");
    tag.className = "topic-tag";
    const keywords = match.matchedKeywords || [];
    tag.textContent = keywords.length > 0 ? `${match.topicName}: ${keywords.join(", ")}` : match.topicName;
    tags.appendChild(tag);
  }
  return tags;
}

function makeLink(href, text) {
  const a = document.createElement("a");
  a.href = href;
  a.target = "_blank";
  a.rel = "noopener noreferrer";
  a.textContent = text;
  return a;
}

function renderPostCard(card, result) {
  const header = document.createElement("div");
  header.className = "result-header";

  const author = document.createElement("span");
  author.className = "author";
  author.textContent = result.author || "Unknown author";
  if (result.isNew) {
    const badge = document.createElement("span");
    badge.className = "new-badge";
    badge.textContent = "NEW";
    author.appendChild(badge);
  }
  if (result.isJobAd) {
    const jobBadge = document.createElement("span");
    jobBadge.className = "job-ad-badge";
    jobBadge.textContent = "IN-POST JOB AD";
    author.appendChild(jobBadge);
  }
  if (result.isHiringPost) {
    const hiringBadge = document.createElement("span");
    hiringBadge.className = "hiring-badge";
    hiringBadge.textContent = "HIRING";
    author.appendChild(hiringBadge);
  }
  if (result.isFreelancePost) {
    const freelanceBadge = document.createElement("span");
    freelanceBadge.className = "freelance-badge";
    freelanceBadge.textContent = "FREELANCE/CONTRACT";
    author.appendChild(freelanceBadge);
  }

  if (result.connectionDegree) {
    const degree = document.createElement("span");
    degree.className = "connection-degree";
    degree.textContent = result.connectionDegree;
    author.appendChild(degree);
  }

  const timestamp = document.createElement("span");
  timestamp.className = "timestamp";
  timestamp.textContent = result.timestampText || "";

  header.append(author, timestamp);

  const headline = document.createElement("div");
  headline.className = "headline";
  headline.textContent = result.headline || "";

  const snippet = document.createElement("div");
  snippet.className = "snippet";
  snippet.textContent = result.snippet;

  const links = document.createElement("div");
  if (result.postUrl) links.appendChild(makeLink(result.postUrl, "View Post"));
  if (result.profileUrl) links.appendChild(makeLink(result.profileUrl, "View Profile"));

  card.append(header, headline, buildTagsEl(result.matchedTopics), snippet, links);
  buildDraftSection(card, result);
}

function renderJobCard(card, result) {
  card.classList.add("job-result-card");

  const header = document.createElement("div");
  header.className = "result-header";

  const title = document.createElement("span");
  title.className = "author";
  title.textContent = result.title || "Untitled role";
  if (result.isNew) {
    const badge = document.createElement("span");
    badge.className = "new-badge";
    badge.textContent = "NEW";
    title.appendChild(badge);
  }
  const jobBadge = document.createElement("span");
  jobBadge.className = "job-ad-badge";
  jobBadge.textContent = "JOB LISTING";
  title.appendChild(jobBadge);

  const timestamp = document.createElement("span");
  timestamp.className = "timestamp";
  timestamp.textContent = result.postedText || "";

  header.append(title, timestamp);

  const headline = document.createElement("div");
  headline.className = "headline";
  headline.textContent = [result.company, result.location].filter(Boolean).join(" · ");

  const links = document.createElement("div");
  if (result.jobUrl) links.appendChild(makeLink(result.jobUrl, "View Job"));

  card.append(header, headline, buildTagsEl(result.matchedTopics), links);
}

function renderResults(sortedResults) {
  resultsListEl.innerHTML = "";

  if (sortedResults.length === 0) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "No results yet. Run a scan to find leads.";
    resultsListEl.appendChild(empty);
    return;
  }

  for (const result of sortedResults) {
    const card = document.createElement("div");
    card.className = "result-card";

    if (result.type === "job") {
      renderJobCard(card, result);
    } else {
      renderPostCard(card, result);
    }

    resultsListEl.appendChild(card);
  }
}

// Re-reads results from storage and re-renders the list - used after the
// advisor agent drafts a message via its draft_message tool, so the visible
// lead card in the Results section picks up the new draft too.
async function renderResultsFromStorage() {
  const resultsMap = await getResults();
  const sorted = sortResultsByRelevance(resultsMap).map((r) => ({ ...r, isNew: false }));
  renderResults(sorted);
}

timeframeSelect.addEventListener("change", () => {
  saveTimeframe(timeframeSelect.value);
});

authorTitleInput.addEventListener("input", () => {
  const titles = authorTitleInput.value
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line.length > 0);
  saveAuthorTitles(titles);
});

authorTitleEnabledCheckbox.addEventListener("change", () => {
  authorTitleInput.disabled = !authorTitleEnabledCheckbox.checked;
  saveAuthorTitleEnabled(authorTitleEnabledCheckbox.checked);
});

includeJobAdsCheckbox.addEventListener("change", () => {
  saveIncludeJobAds(includeJobAdsCheckbox.checked);
});

jobSearchEnabledCheckbox.addEventListener("change", () => {
  saveJobSearchEnabled(jobSearchEnabledCheckbox.checked);
});

jobSearchUsePostTopicsCheckbox.addEventListener("change", () => {
  saveJobSearchUsePostTopics(jobSearchUsePostTopicsCheckbox.checked);
});

jobSearchLocationSelect.addEventListener("change", () => {
  saveJobSearchLocation(jobSearchLocationSelect.value);
});

jobSearchTimeframeSelect.addEventListener("change", () => {
  saveJobSearchTimeframe(jobSearchTimeframeSelect.value);
});

// API keys are always plain ASCII - stripping anything outside the printable
// ASCII range guards against invisible/smart-typography characters that can
// sneak in when copy-pasting (from a chat UI, a doc, etc.), which otherwise
// make fetch() reject the request outright ("non ISO-8859-1 code point").
function sanitizeApiKey(value) {
  return value.replace(/[^\x20-\x7E]/g, "").trim();
}

anthropicApiKeyInput.addEventListener("input", () => {
  saveAnthropicApiKey(sanitizeApiKey(anthropicApiKeyInput.value));
});

outputLanguageSelect.addEventListener("change", () => {
  outputLanguage = outputLanguageSelect.value;
  saveOutputLanguage(outputLanguage);
});

companyContextInput.addEventListener("input", () => {
  companyContext = companyContextInput.value;
  saveCompanyContext(companyContext);
});

mentorPersonaInput.addEventListener("input", () => {
  mentorPersona = mentorPersonaInput.value;
  saveMentorPersona(mentorPersona);
});

customerPersonaInput.addEventListener("input", () => {
  customerPersona = customerPersonaInput.value;
  saveCustomerPersona(customerPersona);
});

valueAddOffersInput.addEventListener("input", () => {
  valueAddOffers = valueAddOffersInput.value
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line.length > 0);
  saveValueAddOffers(valueAddOffers);
});

// Shared by the manual Export Settings button and the automatic pre-scan
// backup below. Settings already save immediately on every edit, so this
// isn't protecting against unsaved changes - it's a real file outside
// chrome.storage.local entirely, which is what actually survives things a
// storage-level save can't: switching the unpacked extension to a different
// folder (a different folder path is a different extension ID to Chrome,
// with its own empty storage), a corrupted profile, or an accidental
// uninstall.
async function downloadSettingsBackup(filenamePrefix, includeApiKey = false) {
  const data = await exportSettings(includeApiKey);
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${filenamePrefix}-${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

exportBtn.addEventListener("click", async () => {
  const includeApiKey = exportIncludeApiKeyCheckbox.checked;
  if (includeApiKey && !confirm(
    "This export will include your Anthropic API key in plain text. Only send this file to people you " +
    "trust with that key's spending. Continue?"
  )) {
    return;
  }
  await downloadSettingsBackup("salesteam-backup", includeApiKey);
});

importBtn.addEventListener("click", () => {
  importFileInput.click();
});

importFileInput.addEventListener("change", async () => {
  const file = importFileInput.files[0];
  importFileInput.value = "";
  if (!file) return;

  let data;
  try {
    data = JSON.parse(await file.text());
  } catch {
    alert("That file isn't valid JSON - couldn't import it.");
    return;
  }

  if (!confirm("Import this backup? It will replace your current topics, filters, and results.")) return;

  await importSettings(data);
  await init();
});

exportCsvBtn.addEventListener("click", async () => {
  const resultsMap = await getResults();
  const sorted = sortResultsByRelevance(resultsMap);
  if (sorted.length === 0) {
    alert("No leads to export yet - run a scan first.");
    return;
  }

  const csv = resultsToCsv(sorted);
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `linkedin-leads-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
});

clearResultsBtn.addEventListener("click", async () => {
  if (!confirm("Clear all saved leads? This can't be undone.")) return;
  await clearResults();
  renderResults([]);
});

scanBtn.addEventListener("click", async () => {
  scanBtn.disabled = true;
  progressTextEl.textContent = "Backing up settings…";
  // A real file outside the extension's own storage - see
  // downloadSettingsBackup's comment for why this is the backup that
  // actually matters, not a chrome.storage.local save (which already
  // happens continuously as you type, independent of scanning).
  await downloadSettingsBackup("salesteam-auto-backup").catch((err) => {
    console.error("[SalesTeam] Pre-scan settings backup failed:", err);
  });
  progressTextEl.textContent = "Starting scan…";
  chrome.runtime.sendMessage({ type: "SCAN_ALL" });
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "SCAN_PROGRESS") {
    progressTextEl.textContent = `Searching: ${message.topicName} (${message.current} of ${message.total})…`;
  } else if (message?.type === "SCAN_COMPLETE") {
    progressTextEl.textContent = `Scan complete — ${message.results.length} total leads.`;
    scanBtn.disabled = false;
    renderResults(message.results);
  } else if (message?.type === "SCAN_ERROR") {
    progressTextEl.textContent = message.message;
    scanBtn.disabled = false;
    renderResultsFromStorage(); // pick up any leads saved before the failure
  }
});

async function init() {
  document.getElementById("version-text").textContent = `v${chrome.runtime.getManifest().version}`;

  topics = await getTopics();
  renderTopics();

  jobTopics = await getJobTopics();
  renderJobTopics();

  timeframeSelect.value = await getTimeframe();
  authorTitleInput.value = (await getAuthorTitles()).join("\n");
  authorTitleEnabledCheckbox.checked = await getAuthorTitleEnabled();
  authorTitleInput.disabled = !authorTitleEnabledCheckbox.checked;
  includeJobAdsCheckbox.checked = await getIncludeJobAds();

  jobSearchEnabledCheckbox.checked = await getJobSearchEnabled();
  jobSearchUsePostTopicsCheckbox.checked = await getJobSearchUsePostTopics();
  jobLocationPresets = await getJobSearchLocationPresets();
  renderJobLocationOptions(await getJobSearchLocation());
  jobSearchTimeframeSelect.value = await getJobSearchTimeframe();

  outputLanguage = await getOutputLanguage();
  outputLanguageSelect.value = outputLanguage;

  companyContext = await getCompanyContext();
  companyContextInput.value = companyContext;

  mentorPersona = await getMentorPersona();
  mentorPersonaInput.value = mentorPersona;

  customerPersona = await getCustomerPersona();
  customerPersonaInput.value = customerPersona;

  anthropicApiKeyInput.value = await getAnthropicApiKey();
  messageTemplates = await getMessageTemplates();
  renderMessageTemplates();
  valueAddOffers = await getValueAddOffers();
  valueAddOffersInput.value = valueAddOffers.join("\n");

  await salesMentor.init();
  await customerVoice.init();

  await renderResultsFromStorage();
}

init();
