import {
  getTopics,
  getJobTopics,
  getResults,
  saveResults,
  mergeTopicPosts,
  mergeJobPosts,
  getTimeframe,
  getJobSearchEnabled,
  getJobSearchUsePostTopics,
  getJobSearchLocation,
  getJobSearchTimeframe,
} from "./storage.js";
import { sortResultsByRelevance } from "./ranking.js";

const SCRAPE_TIMEOUT_MS = 15000;
const MIN_DELAY_MS = 3000;
const MAX_DELAY_MS = 8000;

// Confirmed empirically: a single parenthesized OR-group in LinkedIn's
// keyword search tops out at 6 terms (6 works, 7 silently returns zero, no
// error), and combining two ANDed OR-groups in one query tops out at 9
// terms total across both. A topic's keywords are its primary OR-group; it
// can optionally have a second "andKeywords" OR-group requiring a post to
// ALSO mention one of those (e.g. concept terms AND activity terms). Both
// limits are enforced by chunking. Location/author-title filters are
// deliberately NOT sent to LinkedIn at all (see content-script.js) - they're
// applied client-side against each post's scraped headline instead, so they
// never compete with a topic's own two groups for this budget.
const MAX_OR_TERMS = 6;
const TOTAL_TERM_BUDGET = 9;

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

function chunk(array, size) {
  if (array.length === 0) return [[]];
  const chunks = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
}

function buildSearchUrl(conceptChunk, activityChunk, timeframe) {
  const toClauses = (list) =>
    list.filter((k) => k.trim().length > 0).map((k) => (k.includes(" ") ? `"${k.trim()}"` : k.trim()));

  let query = toClauses(conceptChunk).join(" OR ");
  if (activityChunk && activityChunk.length > 0) {
    query = `(${query}) AND (${toClauses(activityChunk).join(" OR ")})`;
  }

  const sortBy = encodeURIComponent('["relevance"]');
  let url = `https://www.linkedin.com/search/results/content/?keywords=${encodeURIComponent(query)}&origin=FACETED_SEARCH&sortBy=${sortBy}`;
  if (timeframe && timeframe !== "any") {
    url += `&datePosted=${encodeURIComponent(`["${timeframe}"]`)}`;
  }
  return url;
}

// When a topic has both a primary keyword group and an optional "AND with"
// group, splits the shared 9-term budget between them - shrinking whichever
// group is currently larger, one term at a time, until both individually
// fit MAX_OR_TERMS and their sum fits TOTAL_TERM_BUDGET.
function splitBudget(countA, countB) {
  let sizeA = Math.min(MAX_OR_TERMS, countA);
  let sizeB = Math.min(MAX_OR_TERMS, countB);
  while (sizeA + sizeB > TOTAL_TERM_BUDGET && (sizeA > 1 || sizeB > 1)) {
    if (sizeA >= sizeB && sizeA > 1) sizeA--;
    else if (sizeB > 1) sizeB--;
    else break;
  }
  return { sizeA, sizeB };
}

function planTopicChunks(topic) {
  const activityKeywords = topic.andKeywords || [];
  if (activityKeywords.length === 0) {
    return { conceptChunks: chunk(topic.keywords, MAX_OR_TERMS), activityChunks: [[]] };
  }
  const { sizeA, sizeB } = splitBudget(topic.keywords.length, activityKeywords.length);
  return { conceptChunks: chunk(topic.keywords, sizeA), activityChunks: chunk(activityKeywords, sizeB) };
}

// Jobs search uses a completely different LinkedIn system than Posts (own
// URL, own filters: geoId for location, f_TPR for date posted in seconds -
// r86400/r604800/r2592000 for 24h/week/month). We haven't separately
// confirmed Jobs' own term-complexity limit, so this reuses the same
// MAX_OR_TERMS=6 assumption that's confirmed for Posts as a safe starting
// point - a single 6-term job search was tested live and worked.
const JOB_TPR_SECONDS = { "past-24h": 86400, "past-week": 604800, "past-month": 2592000 };

function buildJobSearchUrl(keywordChunk, geoId, timeframe) {
  const clauses = keywordChunk
    .filter((k) => k.trim().length > 0)
    .map((k) => (k.includes(" ") ? `"${k.trim()}"` : k.trim()));
  const query = clauses.join(" OR ");

  let url = `https://www.linkedin.com/jobs/search-results/?keywords=${encodeURIComponent(query)}`;
  if (geoId) url += `&geoId=${encodeURIComponent(geoId)}`;
  const seconds = JOB_TPR_SECONDS[timeframe];
  if (seconds) url += `&f_TPR=r${seconds}`;
  return url;
}

function waitForJobScrapeResult(topicId) {
  return new Promise((resolve) => {
    let settled = false;
    const timeout = setTimeout(() => {
      if (!settled) {
        settled = true;
        chrome.runtime.onMessage.removeListener(listener);
        resolve([]);
      }
    }, SCRAPE_TIMEOUT_MS);

    function listener(message) {
      if (message?.type === "JOB_SCRAPE_RESULT" && message.topicId === topicId && !settled) {
        settled = true;
        clearTimeout(timeout);
        chrome.runtime.onMessage.removeListener(listener);
        resolve(message.jobs || []);
      }
    }
    chrome.runtime.onMessage.addListener(listener);
  });
}

function fullTopicMatchedJobKeywords(job, topic) {
  const allKeywords = [...topic.keywords, ...(topic.andKeywords || [])];
  const haystack = `${job.title} ${job.company}`.toLowerCase();
  return allKeywords.filter((kw) => containsWholeWord(haystack, kw));
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function randomDelay() {
  return MIN_DELAY_MS + Math.random() * (MAX_DELAY_MS - MIN_DELAY_MS);
}

// Breaks a delay into short chunks with a trivial storage read between each,
// instead of one continuous setTimeout. Manifest V3 service workers can be
// terminated by Chrome after a period with no extension-API activity - a
// long scan's cumulative delay time sitting as one idle wait is a plausible
// cause of a scan silently freezing partway through with no error ever
// shown (each API touch here resets that idle clock). Best-effort mitigation,
// not a guaranteed fix - Chrome doesn't document the exact idle threshold.
async function keepAliveSleep(totalMs) {
  const STEP_MS = 5000;
  let remaining = totalMs;
  while (remaining > 0) {
    const step = Math.min(STEP_MS, remaining);
    await sleep(step);
    await chrome.storage.local.get("keepAlive").catch(() => {});
    remaining -= step;
  }
}

// A timeout fallback here matters: with none, a page that never fires
// "complete" (a proxy, a corporate security interstitial, an unusually slow
// or managed network - all plausible causes that wouldn't show up on every
// machine) hangs this forever with nothing ever thrown, so even the error
// handling around the scan's main loop can't catch or report it - the scan
// just sits stuck with no message, indistinguishable from before that fix
// existed. Proceeding anyway after a timeout means the content script gets
// a chance to scrape whatever did load, rather than blocking the whole scan.
const NAVIGATION_TIMEOUT_MS = 20000;

function navigateAndWait(tabId, url) {
  return new Promise((resolve) => {
    let settled = false;
    const timeout = setTimeout(() => {
      if (!settled) {
        settled = true;
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }, NAVIGATION_TIMEOUT_MS);

    function listener(updatedTabId, changeInfo) {
      if (updatedTabId === tabId && changeInfo.status === "complete" && !settled) {
        settled = true;
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    // Register the listener before navigating so a fast page load can't
    // fire "complete" before we're listening for it.
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.update(tabId, { url });
  });
}

function waitForScrapeResult(topicId) {
  return new Promise((resolve) => {
    let settled = false;
    const timeout = setTimeout(() => {
      if (!settled) {
        settled = true;
        chrome.runtime.onMessage.removeListener(listener);
        resolve([]);
      }
    }, SCRAPE_TIMEOUT_MS);

    function listener(message) {
      if (message?.type === "SCRAPE_RESULT" && message.topicId === topicId && !settled) {
        settled = true;
        clearTimeout(timeout);
        chrome.runtime.onMessage.removeListener(listener);
        resolve(message.posts || []);
      }
    }
    chrome.runtime.onMessage.addListener(listener);
  });
}

function broadcastProgress(current, total, topicName) {
  chrome.runtime.sendMessage({ type: "SCAN_PROGRESS", current, total, topicName }).catch(() => {});
}

function escapeRegExp(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// Whole-word match, not raw substring - a naive .includes() on a short
// keyword like "AI" also matches inside unrelated words (e.g. "AljurAId"),
// which is a real false-positive source for 2-3 letter terms.
function containsWholeWord(haystackLower, keyword) {
  return new RegExp(`\\b${escapeRegExp(keyword.toLowerCase())}\\b`, "i").test(haystackLower);
}

// Re-checks a post against the topic's FULL keyword lists (both groups),
// not just the specific chunk that happened to be searched when this post
// was found. A topic's keywords get split into multiple sub-searches, so
// the chunk that surfaced a given post is only a subset of everything you
// actually configured for that topic - this shows every configured keyword
// that's genuinely present in the text, not just the ones from that one
// sub-search.
function fullTopicMatchedKeywords(post, topic) {
  const allKeywords = [...topic.keywords, ...(topic.andKeywords || [])];
  const haystack = `${post.snippet} ${post.headline}`.toLowerCase();
  return allKeywords.filter((kw) => containsWholeWord(haystack, kw));
}

async function scanAllTopics() {
  const allTopics = await getTopics();
  const topics = allTopics.filter((topic) => topic.enabled !== false);
  if (topics.length === 0) {
    chrome.runtime
      .sendMessage({
        type: "SCAN_ERROR",
        message:
          allTopics.length === 0
            ? "No topics configured."
            : "All topics are disabled - enable at least one to scan.",
      })
      .catch(() => {});
    return;
  }

  const existingResults = await getResults();
  const preScanKeys = new Set(Object.keys(existingResults));
  let tab = null;
  let previouslyActiveTab = null;

  try {
    const timeframe = await getTimeframe();

    const jobSearchEnabled = await getJobSearchEnabled();
    const jobSearchLocation = await getJobSearchLocation();
    const jobSearchTimeframe = await getJobSearchTimeframe();

    // Job Search's topics are additive with Posts', not either/or: job-only
    // topics (e.g. "AI Engineer" OR "ML Engineer") always apply, and this
    // toggle controls whether the enabled Post topics ALSO get searched in
    // Jobs on top of those.
    const jobSearchUsePostTopics = await getJobSearchUsePostTopics();
    const allJobTopics = await getJobTopics();
    const enabledJobOnlyTopics = allJobTopics.filter((topic) => topic.enabled !== false);
    const jobTopics = jobSearchUsePostTopics ? [...topics, ...enabledJobOnlyTopics] : enabledJobOnlyTopics;

    // Jobs search reuses each topic's combined keywords (both groups treated
    // as one flat OR list - job titles/descriptions are concise enough that
    // the concept/activity AND-split built for Posts isn't needed here).
    const jobKeywordChunks = jobSearchEnabled
      ? jobTopics.map((topic) => chunk([...topic.keywords, ...(topic.andKeywords || [])], MAX_OR_TERMS))
      : [];

    const topicChunkPlans = topics.map(planTopicChunks);
    const postSubQueries = topicChunkPlans.reduce(
      (sum, plan) => sum + plan.conceptChunks.length * plan.activityChunks.length,
      0
    );
    const jobSubQueries = jobKeywordChunks.reduce((sum, chunks) => sum + chunks.length, 0);
    const totalSubQueries = postSubQueries + jobSubQueries;

    tab = await chrome.tabs.create({ url: "about:blank", active: false });

    let completed = 0;
    for (let i = 0; i < topics.length; i++) {
      const topic = topics[i];
      const { conceptChunks, activityChunks } = topicChunkPlans[i];

      await chrome.storage.local.set({
        currentScanTopicId: topic.id,
        currentScanTopicName: topic.name,
      });

      for (const conceptChunk of conceptChunks) {
        for (const activityChunk of activityChunks) {
          completed++;
          broadcastProgress(completed, totalSubQueries, topic.name);

          await chrome.storage.local.set({ currentScanKeywords: [...conceptChunk, ...activityChunk] });
          await navigateAndWait(tab.id, buildSearchUrl(conceptChunk, activityChunk, timeframe));

          const posts = await waitForScrapeResult(topic.id);
          for (const post of posts) {
            post.matchedKeywords = fullTopicMatchedKeywords(post, topic);
          }
          console.log(`[SalesTeam] topic "${topic.name}" (sub-query ${completed}/${totalSubQueries}), concept:`, conceptChunk, `AND:`, activityChunk);
          for (const post of posts) {
            console.log(`  - ${post.author}: matchedKeywords=`, post.matchedKeywords, `snippet="${post.snippet.slice(0, 100)}"`);
          }
          mergeTopicPosts(existingResults, topic, posts);

          if (completed < totalSubQueries) {
            await keepAliveSleep(randomDelay());
          }
        }
      }

      await chrome.storage.local.remove(["currentScanTopicId", "currentScanTopicName"]);
      // Checkpoint after each topic, not just at the very end - so a later
      // failure/timeout doesn't lose everything found so far in this scan.
      await saveResults(existingResults);
    }

    if (jobSearchEnabled && jobTopics.length > 0) {
      // LinkedIn's Jobs list is a viewport-virtualized component - unlike the
      // Posts feed, it appears to render zero items when its tab has never
      // been visible/laid out (confirmed empirically: 0 jobs across 8 varied
      // queries that should have had real matches). Bring the tab to the
      // foreground just for this phase, then restore whatever was focused
      // before the scan started.
      [previouslyActiveTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      await chrome.tabs.update(tab.id, { active: true });

      for (let i = 0; i < jobTopics.length; i++) {
        const topic = jobTopics[i];
        const keywordChunks = jobKeywordChunks[i];
        if (keywordChunks.length === 0) continue;

        await chrome.storage.local.set({
          currentJobScanTopicId: topic.id,
          currentJobScanTopicName: topic.name,
        });

        for (const keywordChunk of keywordChunks) {
          completed++;
          broadcastProgress(completed, totalSubQueries, `${topic.name} (Jobs)`);

          await chrome.storage.local.set({ currentJobScanKeywords: keywordChunk });
          await navigateAndWait(tab.id, buildJobSearchUrl(keywordChunk, jobSearchLocation, jobSearchTimeframe));

          const jobs = await waitForJobScrapeResult(topic.id);
          for (const job of jobs) {
            job.matchedKeywords = fullTopicMatchedJobKeywords(job, topic);
          }
          console.log(`[SalesTeam] job search topic "${topic.name}" (sub-query ${completed}/${totalSubQueries}), keywords:`, keywordChunk);
          for (const job of jobs) {
            console.log(`  - "${job.title}" @ ${job.company}: matchedKeywords=`, job.matchedKeywords);
          }
          mergeJobPosts(existingResults, topic, jobs);

          if (completed < totalSubQueries) {
            await keepAliveSleep(randomDelay());
          }
        }

        await chrome.storage.local.remove(["currentJobScanTopicId", "currentJobScanTopicName"]);
        // Checkpoint after each job topic too, same reasoning as above.
        await saveResults(existingResults);
      }
    }

    const sorted = sortResultsByRelevance(existingResults).map((r) => ({
      ...r,
      isNew: !preScanKeys.has(r.key),
    }));
    chrome.runtime.sendMessage({ type: "SCAN_COMPLETE", results: sorted }).catch(() => {});
  } catch (err) {
    // Without this, any error here (a closed tab, a transient extension API
    // failure, Chrome terminating this service worker mid-run - a known
    // Manifest V3 risk for long-running background tasks) used to kill the
    // scan silently: no message ever reached the side panel, the Scan
    // button stayed disabled forever, and everything found in that run was
    // lost since results were only saved at the very end.
    console.error("[SalesTeam] Scan failed:", err);
    await saveResults(existingResults).catch(() => {});
    chrome.runtime
      .sendMessage({
        type: "SCAN_ERROR",
        message:
          `Scan stopped early due to an error (${err?.message || err}). Leads found before the error ` +
          "were saved - check Results, then try scanning again to pick up the rest.",
      })
      .catch(() => {});
  } finally {
    if (previouslyActiveTab) {
      await chrome.tabs.update(previouslyActiveTab.id, { active: true }).catch(() => {});
    }
    if (tab) {
      await chrome.tabs.remove(tab.id).catch(() => {});
    }
  }
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "SCAN_ALL") {
    scanAllTopics();
  }
});
