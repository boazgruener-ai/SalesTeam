# LinkedIn Lead Scanner — v0.5.0

## New since v0.4.1

- **Mentor persona setting** (in the Sales Mentor section) — describes the Mentor's background/style (e.g. years of experience, industry focus, tone). Pre-filled with a sensible default; edit it to match how you actually want advice delivered.
- **Target customer persona setting** (in the Customer Voice section) — describes who your ideal buyer actually is (company type, role, seniority). Used only for general questions with no specific lead named; a named real lead's actual data always takes priority over this generic persona.
- Both are included in Export/Import Settings, so they can be shared to a second installation the same way Topics and templates already are.

---

# LinkedIn Lead Scanner — v0.4.1

## Fixes since v0.4.0

- **Connection-degree detection now actually works.** The scraper was checking a `data-view-name="null"` attribute that's present (as that literal string) on nearly every element in LinkedIn's DOM, so it always matched the wrong node and came back empty. Fixed to walk up to the first ancestor with real text, confirmed against live posts (1st/2nd/3rd correctly detected).
- **New "What We Offer" setting**, shared by AI drafting, the Sales Mentor, and Customer Voice. Previously all three reasoned only from a lead's own post, with zero idea what your company actually sells — meaning advice and drafts couldn't reason about real fit, only surface relevance. Add a description once in AI Message Drafting settings and all three features pick it up immediately.
- **Longer agent replies.** Sales Mentor and Customer Voice were capped at 1024 tokens, cutting off detailed strategic answers mid-sentence. Raised to 2048.

---

# LinkedIn Lead Scanner — v0.4.0

## New since v0.3.0

**An "AI board of advisors" — two agents built on shared infrastructure**
- The former "Sales Advisor" is now the **Sales Mentor**: a 25-years-experience, always-available persona. Answers general strategy questions directly from its own expertise, and only reaches for the `list_leads`/`get_lead_details` tools when a question is actually about specific leads — the same agent handles both without you needing to pick a mode.
- New **Customer Voice** agent: roleplays as a realistic B2B buyer so you can bounce a message or approach off it before sending. Name a specific lead and it grounds itself in their real scraped post (via the same tools, read-only); ask a general question and it answers as a typical buyer in this space instead.
- Both agents are built from one reusable chat engine (same tool-use loop, different persona/system prompt/tool access) — a genuine multi-agent architecture sharing infrastructure, not three separate one-off builds.

---

# LinkedIn Lead Scanner — v0.3.0

## New since v0.2.0

**Sales Advisor (a real AI agent, not just generative text)**
- A chat panel where you can ask things like "Which lead should I approach first?" or "How should I approach Gabel?"
- Unlike the message drafter (a single fixed prompt), this gives Claude tools it decides on its own whether to use: `list_leads` (survey what's available), `get_lead_details` (dig into one lead), and `draft_message` (generate a draft as part of its answer) — genuine multi-step tool-calling, the core mechanic of agentic AI.
- Uses a stronger model (Sonnet) than the drafting feature, since giving real prioritization/approach advice is a reasoning task, not a quick templated draft.
- All three tools only read/generate local data already in your Results list — none of them touch LinkedIn or send anything.
- Conversation persists across closing/reopening the side panel; "Clear Conversation" resets it.

---

# LinkedIn Lead Scanner — v0.2.0

## New since v0.1.0

**AI-drafted opening messages (Post leads only)**
- "Draft Message" button on each Post lead generates a short, personalized LinkedIn message via Claude, using that lead's matched post content, headline, and topic — never auto-sent, always shown as editable text with a Copy button, so you review and send it yourself inside LinkedIn.
- Three editable templates (auto-picked per lead, or choose manually): already connected (1st-degree), not yet connected, and hiring/job-ad leads — each with its own tone.
- An optional "things you can offer" list (a real article, report, or demo offer) the AI may reference — it's instructed to never invent one that isn't on your list.
- Requires your own Anthropic API key, entered under "AI Message Drafting" in settings (stored locally only, and excluded from Export/Import Settings so each installation uses its own key).
- Best-effort detection of LinkedIn's 1st/2nd/3rd-degree connection badge to pick the right template tone — not yet live-verified against LinkedIn's current DOM, so it may need the same kind of selector tuning as other scraping in this extension.

---

# LinkedIn Lead Scanner — v0.1.0 (First Alpha)

A Chrome extension that manually scans LinkedIn for people and companies talking about — or hiring for — topics you care about, so you can find and reach out to real leads instead of scrolling your feed.

## What it does

**Topics**
- Define named topics as keyword lists (e.g. "AI Transformation": AI, Artificial Intelligence, Machine Learning...).
- Each topic can optionally have a second "AND with" group, so a post must mention something from *both* groups (e.g. an AI term AND a project/development term).
- Enable/disable individual topics without deleting them or losing their keywords.
- No need to keep keyword lists short — LinkedIn silently breaks on overly long/complex searches, so the extension automatically splits a topic into multiple smaller searches behind the scenes and merges the results back into one list.

**One-click scanning**
- "Scan All Topics" runs every enabled topic as its own search, then merges everything into a single list, ranked by relevance (posts/jobs matching more topics rank higher, then by how well-matched and how recent).
- Fully manual — nothing runs automatically or on a schedule, so there's no risk to your LinkedIn account from unattended automation.

**Posts Search filters**
- "Posted within" timeframe (any time / 24h / week / month).
- "Author title contains" — narrow to specific job titles (CTO, Director, VP, etc.), checked against each author's visible headline.
- Include/exclude posts that have an embedded job ad.

**Job Search (LinkedIn's separate Jobs section)**
- Toggle on to also search LinkedIn Jobs listings, not just Posts.
- Job-specific topics (e.g. "AI Engineer" OR "ML Engineer") — additive with your Post topics, not a replacement.
- Location filter (Switzerland, Zurich Metropolitan Area, and you can add more locations yourself).
- Its own independent "Date posted" filter, since job ads go stale much faster than posts.

**Lead types, clearly labeled**
- **Post** — someone's personal post matching a topic.
- **In-Post Job Ad** — a post with LinkedIn's job-listing widget attached.
- **Job Listing** — a result from LinkedIn's dedicated Jobs section.
- **Hiring** / **Freelance/Contract** badges — flags plain-text posts that use hiring or freelance-outsourcing language, even without a formal job widget.
- **NEW** badge — marks leads found for the first time since your last scan.

**Every result shows**
- Which topic(s) and which specific keyword(s) actually matched.
- Author/company, headline, snippet or job details, and a direct link to the profile, post, or job.

**Managing your data**
- **Export Leads (CSV)** — download all leads for Excel/Sheets/CRM.
- **Export/Import Settings** — back up or transfer your topics, filters, and lead history as a JSON file (e.g. to set up a second person with your tuned topics).
- **Clear Results** — wipe accumulated leads and start fresh.

## Known limitations (alpha)

- Location/author-title filtering for Posts is approximate — it checks the visible headline/post text, not LinkedIn's full profile data.
- No exact post permalink for most posts (LinkedIn doesn't expose one without extra clicks) — you get a link to the author's profile and the visible snippet instead.
- LinkedIn's search-complexity limits (and the Jobs vertical's virtualized list requiring a visible tab) were reverse-engineered through live testing — they could shift if LinkedIn changes its site.
- Currently assumes an English-language LinkedIn UI.
